"use strict";

sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel"], function (__BaseController, JSONModel) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.flexso.cap.dsp.hdi.controller
   */
  const Initial = BaseController.extend("com.flexso.cap.dsp.hdi.controller.Initial", {
    onInit: function _onInit() {
      const model = this.getOwnerComponent().getModel();
      let aEntitySets = model.getServiceMetadata().dataServices.schema[0].entityContainer[0].entitySet.map(entitySet => {
        return {
          name: entitySet.name
        };
      });
      this.setModel(new JSONModel({
        entitySets: aEntitySets,
        selectedEntitySet: ""
      }), "entitySetModel");
    },
    goToEntityTable: function _goToEntityTable() {
      const selectedEntitySet = this.getModel("entitySetModel").getProperty("/selectedEntitySet");
      this.navTo("main", {
        entitySet: selectedEntitySet
      });
    }
  });
  return Initial;
});
//# sourceMappingURL=Initial-dbg.controller.js.map
