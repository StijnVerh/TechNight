"use strict";

sap.ui.define(["sap/m/MessageBox", "./BaseController", "sap/ui/model/json/JSONModel", "sap/ui/core/Fragment", "sap/ui/comp/smartform/SmartForm", "sap/ui/comp/smartform/Group", "sap/ui/comp/smartform/GroupElement", "sap/ui/comp/smartfield/SmartField"], function (MessageBox, __BaseController, JSONModel, Fragment, SmartForm, Group, GroupElement, SmartField) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.flexso.cap.dsp.hdi.controller
   */
  const Main = BaseController.extend("com.flexso.cap.dsp.hdi.controller.Main", {
    onInit: function _onInit() {
      this.smartTable = this.getView().byId("smartTableID");

      // Navigation
      this.getRouter()?.getRoute('main')?.attachPatternMatched(event => this.onMainMatched(event), this);

      // const model: ODataModel = this.getOwnerComponent().getModel() as ODataModel;
      // let aInitiallyVisibleFields: string[] = model.getServiceMetadata().dataServices.schema[0].entityType.find(entityType => entityType.name === entitySet).property.map(property => property.name);
      // let sInitiallyVisibleFields: string = aInitiallyVisibleFields.join(",");

      // this.smartTable.setInitiallyVisibleFields(sInitiallyVisibleFields);
    },
    // *********************************************************************
    // Navigation
    // *********************************************************************
    onMainMatched: async function _onMainMatched(event) {
      this.entitySet = event.getParameter("arguments").entitySet;
      this.setModel(new JSONModel({
        entitySet: this.entitySet
      }), "smartTableModel");
      if (this.smartTable.isInitialised()) {
        location.reload();
      }
      this.setModel(new JSONModel({
        entityType: this.entitySet
      }), "smartFormModel");
    },
    onEditToggled: function _onEditToggled(oEvent) {
      console.log(oEvent);
      const editableTurnedOff = !oEvent.getParameter("editable");
      let oModel = this.smartTable.getModel();
      if (editableTurnedOff) {
        MessageBox.confirm(this.getResourceBundle().getText("confirmSaveMessage"), {
          actions: [MessageBox.Action.YES, MessageBox.Action.NO],
          emphasizedAction: MessageBox.Action.YES,
          onClose: sAction => {
            if (sAction === MessageBox.Action.YES) {
              oModel.submitChanges();
            } else {
              oModel.resetChanges();
              oModel.refresh(true);
            }
          }
        });
      }
    },
    onDelete: function _onDelete(oEvent) {
      let items = this.getView().byId("tableID").getSelectedItems();
      if (items.length === 0) {
        return;
      }
      MessageBox.warning(this.getResourceBundle().getText("deleteWarning"), {
        actions: [MessageBox.Action.YES, MessageBox.Action.CANCEL],
        emphasizedAction: MessageBox.Action.YES,
        onClose: sAction => {
          if (sAction === MessageBox.Action.YES) {
            let oModel = this.smartTable.getModel();
            oModel.setUseBatch(false);
            let items = this.getView().byId("tableID").getSelectedItems();
            items.forEach(item => {
              let key = oModel.getServiceMetadata().dataServices.schema[0].entityType.find(entityType => entityType.name === this.entitySet).key.propertyRef;
              if (key?.length === 1) {
                let id = item.getBindingContext().getProperty(key[0].name);
                oModel.remove(`/${this.entitySet}('${id}')`, {
                  success: () => {
                    oModel.refresh(true);
                  }
                });
              }
            });
          }
        }
      });
    },
    onAdd: async function _onAdd() {
      if (!this.AddEntry) {
        this.AddEntry = await Fragment.load({
          name: "com.flexso.cap.dsp.hdi.view.fragment.AddEntry",
          controller: this
        });
      }
      this.getView().addDependent(this.AddEntry);

      /* Create a new entry */
      let oModel = this.smartTable.getModel();
      const bindingContext = oModel?.createEntry(`/${this.entitySet}`, {});
      this.AddEntry.setBindingContext(bindingContext);
      let aPropertiesOfEntitySet = oModel.getServiceMetadata().dataServices.schema[0].entityType.find(entityType => entityType.name === this.entitySet).property;
      let smartform = this.createSmartform(aPropertiesOfEntitySet);
      this.AddEntry.destroyContent();
      this.AddEntry.addContent(smartform);
      this.AddEntry.open();
    },
    onCancel: function _onCancel() {
      let oModel = this.smartTable.getModel();
      oModel.resetChanges();
      this.AddEntry.close();
    },
    onSave: function _onSave(oEvent) {
      console.log(oEvent);
      let oModel = this.smartTable.getModel();
      oModel.submitChanges();
      this.AddEntry.close();
    },
    onRefresh: function _onRefresh() {
      let oModel = this.smartTable.getModel();
      oModel.refresh(true);
    },
    createSmartform: function _createSmartform(fields) {
      let smartform = new SmartForm({
        editTogglable: false,
        editable: true,
        validationMode: "Async"
      });
      let group = new Group();
      fields.forEach(field => {
        let groupElement = new GroupElement();
        let smartField = new SmartField({
          value: `{${field.name}}`
        });
        groupElement.addElement(smartField);
        group.addGroupElement(groupElement);
      });
      smartform.addGroup(group);
      return smartform;
    }
  });
  return Main;
});
//# sourceMappingURL=Main-dbg.controller.js.map
