"use strict";

sap.ui.define([], function () {
  "use strict";

  var __exports = {
    formatValue: value => {
      return value?.toUpperCase();
    }
  };
  return __exports;
});
//# sourceMappingURL=formatter-dbg.js.map
