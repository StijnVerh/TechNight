export type urlParameters = {
    entitySet: string;
};